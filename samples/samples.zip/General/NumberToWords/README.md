Number to words
===============

Sample & Tutorial by Nestor Kuka

# Screen Shot

![digitstowords](https://raw.githubusercontent.com/ring-lang/ring/master/samples/number2words/number2words.png)


