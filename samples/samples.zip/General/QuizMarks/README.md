QuizMarks Application
=====================

Source Code: https://github.com/ring-lang/ring/blob/master/samples/General/QuizMarks/QuizMarks.ring

A simple example about using

(1) Lists (Input)

![lists](https://raw.githubusercontent.com/ring-lang/ring/master/samples/General/QuizMarks/img/usinglists.png)

(2) CSV Files (Output)

![csv](https://raw.githubusercontent.com/ring-lang/ring/master/samples/General/QuizMarks/img/usingcsv.png)

(3) GUILib (TableWidget)

![gui](https://raw.githubusercontent.com/ring-lang/ring/master/samples/General/QuizMarks/img/usinggui.png)

(4) Many Source Code Files (*.ring)

![manyfiles](https://raw.githubusercontent.com/ring-lang/ring/master/samples/General/QuizMarks/img/manyfiles.png)