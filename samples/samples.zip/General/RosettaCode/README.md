==================
RosettaCode Folder
==================

In this folder we can add samples written in

https://rosettacode.org/wiki/Category:Ring