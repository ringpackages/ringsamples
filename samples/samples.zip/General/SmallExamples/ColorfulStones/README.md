###### Colorful Stones
* Link: https://codeforces.com/contest/265/problem/A