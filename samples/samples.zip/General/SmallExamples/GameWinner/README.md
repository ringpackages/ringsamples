Game Winner
===========

This simple program 

* Print Anton If Anton won more games than Danik
* Print Danik If Danik won more games than Anton 
* If Anton and Danik won the same number of games, print Friendship