Reverse Number
==============

An example on:
* Data Conversion
* Syntax Flexibility