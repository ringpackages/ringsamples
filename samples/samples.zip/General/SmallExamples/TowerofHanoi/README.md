# Tower of Hanoi

* This program outputs the steps to solve Tower of Hanoi using recursive solution
* Author: Tawfik Yasser (2020.09.20)
* For an iterative solution see this link : en.wikipedia.org/wiki/Tower_of_Hanoi#Iterative_solution
