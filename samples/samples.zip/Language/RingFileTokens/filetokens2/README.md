Ring Scanner
============

Get source code file tokens

	ring import.ring

Output

	Keyword     : SEE
	Literal     : Hello, World!
	EndLine