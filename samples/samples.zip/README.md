Samples Folder
==============

In this folder we store the samples created using Ring.

You can start using (AQuickStart) folder.