# Simple Discord Bot in Ring

This example demonstrates a basic Discord bot written in the [Ring](https://ring-lang.github.io/) programming language, using cURL.