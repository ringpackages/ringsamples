======================
Camera and background
======================

Author : Azzedine Ramal