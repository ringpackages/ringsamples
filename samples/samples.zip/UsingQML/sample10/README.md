Charts using QML
================


# Screen Shots

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot1.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot2.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot3.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot4.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot5.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot6.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot7.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot8.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot9.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot10.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot11.png)

![charts](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample10/images/shot12.png)

