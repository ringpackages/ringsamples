Data Visualization using QML
============================


# Screen Shots

![datavis](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample11/images/datavis1.png)

![datavis](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample11/images/datavis2.png)

![datavis](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/UsingQML/sample11/images/datavis3.png)
