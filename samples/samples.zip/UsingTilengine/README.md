# Using RingTilengine 

## Introduction

RingTilengine provides support for Tilengine - The 2D retro graphics engine with raster effects

Tilengine URL: https://github.com/megamarc/Tilengine

## Screen Shots

![RingTilengineScreenShot](https://github.com/ring-lang/ring/blob/master/documents/source/tilengine_shot3.png)

![RingTilengineScreenShot](https://github.com/ring-lang/ring/blob/master/documents/source/tilengine_shot5.png)

![RingTilengineScreenShot](https://github.com/ring-lang/ring/blob/master/documents/source/tilengine_shot8.png)

![RingTilengineScreenShot](https://github.com/ring-lang/ring/blob/master/documents/source/tilengine_shot9.png)




