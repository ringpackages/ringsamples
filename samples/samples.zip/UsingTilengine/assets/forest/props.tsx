<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="props" tilewidth="213" tileheight="223" tilecount="7" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0" type="pepito">
  <image width="193" height="165" source="house.png"/>
 </tile>
 <tile id="1">
  <image width="25" height="33" source="mushroom-brown.png"/>
 </tile>
 <tile id="2">
  <image width="23" height="28" source="mushroom-red.png"/>
 </tile>
 <tile id="3">
  <image width="36" height="36" source="plant.png"/>
 </tile>
 <tile id="4">
  <image width="49" height="29" source="rock.png"/>
 </tile>
 <tile id="5">
  <image width="213" height="223" source="tree.png"/>
 </tile>
 <tile id="6">
  <image width="41" height="53" source="vine.png"/>
 </tile>
</tileset>
