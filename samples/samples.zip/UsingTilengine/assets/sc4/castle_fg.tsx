<?xml version="1.0" encoding="UTF-8"?>
<tileset name="castle_fg" tilewidth="8" tileheight="8" >
	<image source="castle_fg.png" width="128" height="8"/>
</tileset>
