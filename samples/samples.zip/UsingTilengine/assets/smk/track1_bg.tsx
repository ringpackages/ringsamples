<?xml version="1.0" encoding="UTF-8"?>
<tileset name="track1_bg" tilewidth="8" tileheight="8" >
	<image source="track1_bg.png" width="128" height="16"/>
</tileset>
