<?xml version="1.0" encoding="UTF-8"?>
<tileset name="smw_background" tilewidth="8" tileheight="8" tilecount="96" columns="16">
 <image source="smw_background.png" trans="0060b8" width="128" height="48"/>
</tileset>
