<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Base" tilewidth="16" tileheight="16" >
	<image source="Base.png" width="128" height="16"/>
</tileset>
