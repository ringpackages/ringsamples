<?xml version="1.0" encoding="UTF-8"?>
<tileset name="sonic_md_bg1" tilewidth="8" tileheight="8" tilecount="304" columns="16">
 <image source="Sonic_md_bg1.png" trans="2492db" width="128" height="152"/>
</tileset>
