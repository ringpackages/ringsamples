<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Sonic_md_fg1" tilewidth="8" tileheight="8" tilecount="352" columns="16">
 <image source="Sonic_md_fg1.png" trans="0088ee" width="128" height="176"/>
 <tile id="52">
  <animation>
   <frame tileid="324" duration="200"/>
   <frame tileid="323" duration="200"/>
  </animation>
 </tile>
 <tile id="53">
  <animation>
   <frame tileid="325" duration="200"/>
   <frame tileid="106" duration="200"/>
  </animation>
 </tile>
 <tile id="54">
  <animation>
   <frame tileid="326" duration="200"/>
   <frame tileid="107" duration="200"/>
  </animation>
 </tile>
 <tile id="55">
  <animation>
   <frame tileid="327" duration="200"/>
   <frame tileid="323" duration="200"/>
  </animation>
 </tile>
 <tile id="69">
  <animation>
   <frame tileid="328" duration="200"/>
   <frame tileid="112" duration="200"/>
  </animation>
 </tile>
 <tile id="70">
  <animation>
   <frame tileid="329" duration="200"/>
   <frame tileid="113" duration="200"/>
  </animation>
 </tile>
 <tile id="71">
  <animation>
   <frame tileid="330" duration="200"/>
   <frame tileid="114" duration="200"/>
  </animation>
 </tile>
 <tile id="72">
  <animation>
   <frame tileid="331" duration="200"/>
   <frame tileid="115" duration="200"/>
  </animation>
 </tile>
 <tile id="83">
  <animation>
   <frame tileid="332" duration="200"/>
   <frame tileid="120" duration="200"/>
  </animation>
 </tile>
 <tile id="84">
  <animation>
   <frame tileid="333" duration="200"/>
   <frame tileid="121" duration="200"/>
  </animation>
 </tile>
 <tile id="85">
  <animation>
   <frame tileid="334" duration="200"/>
   <frame tileid="122" duration="200"/>
  </animation>
 </tile>
 <tile id="86">
  <animation>
   <frame tileid="335" duration="200"/>
   <frame tileid="123" duration="200"/>
  </animation>
 </tile>
 <tile id="96">
  <animation>
   <frame tileid="336" duration="200"/>
   <frame tileid="323" duration="200"/>
  </animation>
 </tile>
 <tile id="97">
  <animation>
   <frame tileid="337" duration="200"/>
   <frame tileid="130" duration="200"/>
  </animation>
 </tile>
 <tile id="98">
  <animation>
   <frame tileid="338" duration="200"/>
   <frame tileid="131" duration="200"/>
  </animation>
 </tile>
 <tile id="99">
  <animation>
   <frame tileid="339" duration="200"/>
   <frame tileid="323" duration="200"/>
  </animation>
 </tile>
</tileset>
