<?xml version="1.0" encoding="UTF-8"?>
<tileset name="SOTB_bg" tilewidth="8" tileheight="8" tilecount="640" columns="16">
 <image source="SOTB_bg.png" trans="0088aa" width="128" height="320"/>
</tileset>
