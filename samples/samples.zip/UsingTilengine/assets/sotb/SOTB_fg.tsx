<?xml version="1.0" encoding="UTF-8"?>
<tileset name="SOTB_fg" tilewidth="8" tileheight="8" tilecount="832" columns="16">
 <image source="SOTB_fg.png" trans="0088aa" width="128" height="416"/>
</tileset>
