<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tf3_bg2" tilewidth="8" tileheight="8" >
	<image source="tf3_bg2.png" width="128" height="48"/>
</tileset>
