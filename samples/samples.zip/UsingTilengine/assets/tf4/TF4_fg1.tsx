<?xml version="1.0" encoding="UTF-8"?>
<tileset name="TF4_fg1" tilewidth="8" tileheight="8" tilecount="272" columns="16">
 <image source="TF4_fg1.png" trans="88eecc" width="128" height="136"/>
</tileset>
