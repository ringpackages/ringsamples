UsingWINAPI Sample
==================

The file testresource.ring contains an example about reading files in resources

To try this example, build the program using Ring2EXE

	ring2exe testresources.ring
	testresources

Also, You can check the resource file (testresource.rc)