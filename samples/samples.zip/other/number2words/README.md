Number to words
===============

Sample & Tutorial by Nestor Kuka

Topic in Ring Group : https://groups.google.com/forum/#!topic/ring-lang/vaUKdcV_twc

# Screen Shot

![digitstowords](https://raw.githubusercontent.com/ring-lang/ring/master/samples/other/number2words/number2words.png)


