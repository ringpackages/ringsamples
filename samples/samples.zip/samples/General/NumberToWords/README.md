Number to words
===============

Sample & Tutorial by Nestor Kuka

# Screen Shot

![digitstowords](https://raw.githubusercontent.com/ring-lang/ring/master/samples/General/NumberToWords/number2words.png)


