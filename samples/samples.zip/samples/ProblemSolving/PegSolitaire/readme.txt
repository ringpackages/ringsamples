
(1) Senden Sie alle 3 Programme als Anhang

(2) W�hlen Sie den (Dateinamen) so aus, wie er in diesem Ordner angezeigt werden soll: https://github.com/ring-lang/ring/tree/master/samples/other/PegSolitaire

(3) F�gen Sie auch eine kleine (README-Datei) bei, die diese Programme beschreibt

---

PEG SOLITAIRE GAME
------------------
peg solitaire is both a challenge... and a puzzle for the hours of leisure. there are a lot of variations and several ways to successfully solve the puzzle. 

the enclosed version 32 is from the GOLANG fundus and the 14 from EUPHORIA (resp. PHIX) examples were transferred to RING in teamwork (nestor/bert). 

the very rudimentary gui version 32 is just a study for the eventual realization of a complete game with graphical user interface.

general:
https://en.wikipedia.org/wiki/Peg_solitaire

various PEG Games online:
https://www.pegsolitaire.org/

nestor 9.5.2020
