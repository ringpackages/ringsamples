Samples Folder
==============

In this folder we store the samples created using Ring.
