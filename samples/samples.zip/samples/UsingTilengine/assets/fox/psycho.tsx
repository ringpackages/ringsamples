<?xml version="1.0" encoding="UTF-8"?>
<tileset name="psycho" tilewidth="8" tileheight="8" tilecount="160" columns="16">
 <image source="psycho.png" trans="0055ff" width="128" height="80"/>
</tileset>
