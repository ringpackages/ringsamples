<?xml version="1.0" encoding="UTF-8"?>
<tileset name="castle_bg" tilewidth="8" tileheight="8" >
	<image source="castle_bg.png" width="128" height="40"/>
</tileset>
