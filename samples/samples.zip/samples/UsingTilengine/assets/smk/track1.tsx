<?xml version="1.0" encoding="UTF-8"?>
<tileset name="track1" tilewidth="8" tileheight="8" >
	<image source="track1.png" width="128" height="48"/>
</tileset>
