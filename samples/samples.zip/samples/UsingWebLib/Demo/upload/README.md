Temp. Folder for uploading files by users
